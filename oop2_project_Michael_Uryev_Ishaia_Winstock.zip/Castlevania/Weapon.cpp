#include "Weapon.h"

//----------------------------------------------------------
Weapon::Weapon(sf::Vector2f origin)
{
	setPosition(origin);
}

//----------------------------------------------------------
Weapon::~Weapon()
{
}

